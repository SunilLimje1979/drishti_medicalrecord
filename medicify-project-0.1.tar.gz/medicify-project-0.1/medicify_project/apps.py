from django.apps import AppConfig
class Medicify_ProjectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicify_project'